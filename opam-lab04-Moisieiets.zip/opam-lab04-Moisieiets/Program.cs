using System;
using System.Collections.Generic;
using System.Diagnostics;

class Program
{
    private const int N = 7;
    private const int K = 19;
    private const int A = N % 3;
    private const int B = N % 4;
    private const int C = N % 5;

    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Console.WriteLine($"N = {N}, K = {K}, a = {A}, b = {B}, c = {C}");
        List<int> original = CreateMainList(N);
        Console.WriteLine("Основний список: " + FormatList(original));

        List<int> filtered = BuildByCriterion(original, A, K);
        Console.WriteLine($"Завдання 1 — побудова: {FormatList(filtered)}; Count = {filtered.Count}");

        int initialFirst = original.Count > 0 ? original[0] : 0;
        double initialAverage = Average(original);

        List<int> wrong = new List<int>(original);
        List<int> wrongSkipped = RemoveForwardWrong(wrong, C, initialFirst, initialAverage);
        Console.WriteLine("Завдання 2 — хибний цикл: " + FormatList(wrong));
        Console.WriteLine("Елементи, пропущені хибним циклом: " + FormatList(wrongSkipped));

        List<int> backwards = new List<int>(original);
        RemoveFromEnd(backwards, C, initialFirst, initialAverage);
        List<int> rebuilt = BuildWithoutMatches(original, C, initialFirst, initialAverage);
        Console.WriteLine("Завдання 2 — цикл з кінця: " + FormatList(backwards));
        Console.WriteLine("Завдання 2 — новий список: " + FormatList(rebuilt));
        Console.WriteLine("Результати правильних способів однакові: " + ListsEqual(backwards, rebuilt));

        List<int> firstSorted = CreateIncreasingList(10 + K % 5, N);
        List<int> secondSorted = CreateIncreasingList(6 + K % 4, N + 100);
        List<int> merged = MergeSorted(firstSorted, secondSorted);
        Console.WriteLine("Завдання 3 — список 1: " + FormatList(firstSorted));
        Console.WriteLine("Завдання 3 — список 2: " + FormatList(secondSorted));
        Console.WriteLine("Завдання 3 — злиття: " + FormatList(merged));
        Console.WriteLine("Результат упорядкований: " + IsSorted(merged));

        SplitList(original, B, K, out List<int> part1, out List<int> part2);
        Console.WriteLine("Завдання 4 — перша частина: " + FormatList(part1));
        Console.WriteLine("Завдання 4 — друга частина: " + FormatList(part2));
        Console.WriteLine("Сума Count дорівнює Count оригіналу: " +
                          (part1.Count + part2.Count == original.Count));

        Console.WriteLine();
        Console.WriteLine("Завдання 5 — вимірювання часу (мс):");
        RunBenchmarks();
        Console.WriteLine();
        Console.WriteLine("Перевірки крайових випадків:");
        RunEdgeCaseChecks();
    }

    static List<int> CreateMainList(int seed)
    {
        Random rnd = new Random(seed);
        List<int> result = new List<int>(20);
        for (int i = 0; i < 20; i++)
            result.Add(rnd.Next(-9, 10));
        return result;
    }

    static List<int> BuildByCriterion(List<int> source, int a, int k)
    {
        List<int> result = new List<int>(source.Count);
        int divisor = k % 4 + 2;

        for (int i = 0; i < source.Count; i++)
        {
            int value = source[i];
            bool keep;
            if (a == 0)
                keep = value > k % 7;
            else if (a == 1)
                keep = value % divisor == 0;
            else
                keep = value > 0 && value % 2 != 0;

            if (keep)
                result.Add(value);
        }
        return result;
    }

    static bool ShouldRemove(int value, int c, int initialFirst, double initialAverage)
    {
        if (c == 0) return value % 5 == 0;
        if (c == 1) return value % 3 == 0;
        if (c == 2) return value < 0;
        if (c == 3) return value == initialFirst;
        return value < initialAverage;
    }

    // Навмисно хибний варіант: після RemoveAt(i) індекси зсуваються,
    // але цикл збільшує i, тому наступний елемент може бути пропущений.
    static List<int> RemoveForwardWrong(List<int> list, int c, int initialFirst, double initialAverage)
    {
        List<int> skipped = new List<int>();
        for (int i = 0; i < list.Count; i++)
        {
            if (ShouldRemove(list[i], c, initialFirst, initialAverage))
            {
                int removedIndex = i;
                list.RemoveAt(i);
                if (removedIndex < list.Count &&
                    ShouldRemove(list[removedIndex], c, initialFirst, initialAverage))
                {
                    skipped.Add(list[removedIndex]);
                }
            }
        }
        return skipped;
    }

    static void RemoveFromEnd(List<int> list, int c, int initialFirst, double initialAverage)
    {
        for (int i = list.Count - 1; i >= 0; i--)
        {
            if (ShouldRemove(list[i], c, initialFirst, initialAverage))
                list.RemoveAt(i);
        }
    }

    static List<int> BuildWithoutMatches(List<int> source, int c, int initialFirst, double initialAverage)
    {
        List<int> result = new List<int>(source.Count);
        for (int i = 0; i < source.Count; i++)
        {
            if (!ShouldRemove(source[i], c, initialFirst, initialAverage))
                result.Add(source[i]);
        }
        return result;
    }

    static double Average(List<int> list)
    {
        if (list.Count == 0) return 0;
        long sum = 0;
        for (int i = 0; i < list.Count; i++)
            sum += list[i];
        return (double)sum / list.Count;
    }

    static List<int> CreateIncreasingList(int count, int seed)
    {
        Random rnd = new Random(seed);
        List<int> result = new List<int>(count);
        if (count == 0) return result;

        int value = rnd.Next(1, 10);
        result.Add(value);
        for (int i = 1; i < count; i++)
        {
            value += rnd.Next(1, 10);
            result.Add(value);
        }
        return result;
    }

    static List<int> MergeSorted(List<int> first, List<int> second)
    {
        List<int> result = new List<int>(first.Count + second.Count);
        int i = 0, j = 0;

        while (i < first.Count && j < second.Count)
        {
            if (first[i] <= second[j])
                result.Add(first[i++]);
            else
                result.Add(second[j++]);
        }
        while (i < first.Count) result.Add(first[i++]);
        while (j < second.Count) result.Add(second[j++]);
        return result;
    }

    static bool IsSorted(List<int> list)
    {
        for (int i = 1; i < list.Count; i++)
            if (list[i] < list[i - 1]) return false;
        return true;
    }

    static void SplitList(List<int> source, int b, int k, out List<int> first, out List<int> second)
    {
        first = new List<int>(source.Count);
        second = new List<int>(source.Count);
        int threshold = k % 7;

        for (int i = 0; i < source.Count; i++)
        {
            int value = source[i];
            bool goesFirst;
            if (b == 0) goesFirst = value < 0;
            else if (b == 1) goesFirst = value % 2 == 0;
            else if (b == 2) goesFirst = value < threshold;
            else goesFirst = i % 2 == 0;

            if (goesFirst) first.Add(value);
            else second.Add(value);
        }
    }

    static bool ListsEqual(List<int> first, List<int> second)
    {
        if (first.Count != second.Count) return false;
        for (int i = 0; i < first.Count; i++)
            if (first[i] != second[i]) return false;
        return true;
    }

    static string FormatList(List<int> list)
    {
        return "[" + string.Join(", ", list) + "]";
    }

    static void RunBenchmarks()
    {
        const int count = 100_000;
        const int repeats = 1_000;

        // Прогрівальні запуски на 1000 елементів.
        WarmupAdd(false);
        WarmupAdd(true);
        WarmupInsert();
        WarmupContains();

        Stopwatch sw = Stopwatch.StartNew();
        List<int> withoutCapacity = new List<int>();
        for (int i = 0; i < count; i++) withoutCapacity.Add(i);
        sw.Stop();
        double addNoCapacity = sw.Elapsed.TotalMilliseconds;

        sw.Restart();
        List<int> withCapacity = new List<int>(count);
        for (int i = 0; i < count; i++) withCapacity.Add(i);
        sw.Stop();
        double addCapacity = sw.Elapsed.TotalMilliseconds;

        sw.Restart();
        List<int> atBeginning = new List<int>();
        for (int i = 0; i < count; i++) atBeginning.Insert(0, i);
        sw.Stop();
        double insertBeginning = sw.Elapsed.TotalMilliseconds;

        List<int> containsList = new List<int>(count);
        for (int i = 0; i < count; i++) containsList.Add(i);
        sw.Restart();
        int foundCount = 0;
        for (int i = 0; i < repeats; i++)
            if (containsList.Contains(-1)) foundCount++;
        sw.Stop();
        double containsTime = sw.Elapsed.TotalMilliseconds;

        Console.WriteLine($"100000 × Add без місткості: {addNoCapacity:F3}");
        Console.WriteLine($"100000 × Add з місткістю: {addCapacity:F3}");
        Console.WriteLine($"100000 × Insert(0, x): {insertBeginning:F3}");
        Console.WriteLine($"1000 × Contains відсутнього значення: {containsTime:F3}");
        Console.WriteLine($"Insert / Add без місткості: {(addNoCapacity > 0 ? insertBeginning / addNoCapacity : 0):F2} разів");
        Console.WriteLine($"Знайдено відсутнє значення (має бути 0): {foundCount}");
    }

    static void WarmupAdd(bool capacity)
    {
        List<int> list = capacity ? new List<int>(1000) : new List<int>();
        for (int i = 0; i < 1000; i++) list.Add(i);
    }

    static void WarmupInsert()
    {
        List<int> list = new List<int>();
        for (int i = 0; i < 1000; i++) list.Insert(0, i);
    }

    static void WarmupContains()
    {
        List<int> list = new List<int>(1000);
        for (int i = 0; i < 1000; i++) list.Add(i);
        for (int i = 0; i < 10; i++) list.Contains(-1);
    }

    static void RunEdgeCaseChecks()
    {
        List<int> empty = new List<int>();
        List<int> one = new List<int> { 4 };
        List<int> noneMatch = new List<int> { 1, 3, 7 };
        List<int> allMatch = new List<int> { 0, 5, 10 };

        Console.WriteLine($"Порожній список — завдання 1: Count = {BuildByCriterion(empty, A, K).Count}");
        List<int> e1 = BuildWithoutMatches(empty, C, 0, 0);
        List<int> e2 = new List<int>(empty);
        RemoveFromEnd(e2, C, 0, 0);
        SplitList(empty, B, K, out List<int> ep1, out List<int> ep2);
        Console.WriteLine($"Порожній список — завдання 2: Count = {e1.Count}; завдання 3: {IsSorted(MergeSorted(empty, empty))}; завдання 4: {ep1.Count + ep2.Count == empty.Count}");

        Console.WriteLine($"Один елемент — завдання 1: {BuildByCriterion(one, A, K).Count}; завдання 2: {BuildWithoutMatches(one, C, one[0], Average(one)).Count}; завдання 4: " +
                          (CountSplit(one, B, K) == one.Count));

        Console.WriteLine($"Жоден не підходить (приклад для фільтра кратних 5): {BuildByCriterion(noneMatch, 1, 19).Count == 0}");
        Console.WriteLine($"Усі підходять (приклад для фільтра кратних 5): {BuildByCriterion(allMatch, 1, 19).Count == allMatch.Count}");

        Console.WriteLine($"Злиття з порожнім першим списком: {ListsEqual(MergeSorted(empty, one), one)}");
        Console.WriteLine($"Злиття з порожнім другим списком: {ListsEqual(MergeSorted(one, empty), one)}");
    }

    static int CountSplit(List<int> source, int b, int k)
    {
        SplitList(source, b, k, out List<int> first, out List<int> second);
        return first.Count + second.Count;
    }
}
